using System;
using UnityEngine;
using Oyedoyin.Common;

public class CustomInput : MonoBehaviour
{
    public Controller m_vehicle;

    /// <summary>
    /// 
    /// </summary>
    void Update()
    {
        // Set Input Mode to Custom
        if (m_vehicle != null)
        {
            if (m_vehicle.m_inputType != Oyedoyin.Common.Controller.InputType.Custom)
            {
                m_vehicle.m_inputType = Oyedoyin.Common.Controller.InputType.Custom;
            }
        }

        // Base
        float _rawPitchInput = Input.GetAxis("Pitch");
        float _rawRollInput = Input.GetAxis("Roll");
        float _rawYawInput = Input.GetAxis("Rudder");
        float baseThrottleInput = Input.GetAxis("Throttle");
        float _throttleInput = (baseThrottleInput + 1) / 2;
        float baseCollectiveInput = Input.GetAxis("Collective");
        float _collectiveInput = (baseCollectiveInput + 1) / 2;

        float basePropPitch = Input.GetAxis("Propeller");
        float _propPitchInput = (basePropPitch + 1) / 2;
        float baseMixture = Input.GetAxis("Mixture");
        float _mixtureInput = (baseMixture + 1) / 2;

        if (m_vehicle.m_type == Controller.VehicleType.Aircraft)
        {
            // Send Aircraft Controls
            m_vehicle.SendCustomAircraftInputs(
                _rawPitchInput,
                _rawRollInput,
                _rawYawInput,
                _throttleInput,
                _propPitchInput,
                _mixtureInput);
        }
        else
        {
            // Send Helicopter Controls
            m_vehicle.SendCustomHelicopterInputs(
                _rawPitchInput,
                _rawRollInput,
                _rawYawInput,
                _throttleInput,
                _collectiveInput);
        }


        // ----------------------------------------- Commands
        if (Input.GetButtonDown("Start Engine")) { m_vehicle.TurnOnEngines(); }
        if (Input.GetButtonDown("Stop Engine")) { m_vehicle.TurnOffEngines(); }
        if (Input.GetButtonDown("Fire")) { m_vehicle.m_input.FireWeapon(); }
        if (Input.GetButtonDown("Start Engine BandL")) { }; // TurnOnLeftEngines(); }
        if (Input.GetButtonDown("Start Engine BandR")) { }; //TurnOnRightEngines(); }
        if (Input.GetButtonDown("Stop Engine BandL")) { }; //TurnOffLeftEngines(); }
        if (Input.GetButtonDown("Stop Engine BandR")) { }; //TurnOffRightEngines(); }

        // ----------------------------------------- Toggles
        if (Input.GetButtonDown("Parking Brake")) { m_vehicle.m_input.ToggleBrakeState(); }
        if (Input.GetKeyDown(KeyCode.C)) { m_vehicle.m_input.ToggleCameraState(); }
        if (Input.GetButtonDown("Actuate Gear")) { m_vehicle.m_input.ToggleGearState(); }
        if (Input.GetButtonDown("Speed Brake")) { m_vehicle.m_input.ToggleSpeedBrakeState(); }
        if (Input.GetButtonDown("LightSwitch")) { m_vehicle.m_input.ToggleLightState(); }
        if (Input.GetButtonDown("Afterburner"))
        {
            if (!m_vehicle.boostRunning) { m_vehicle.EngageBoost(); }
            else if (m_vehicle.boostRunning) { m_vehicle.DisEngageBoost(); }
        }
        if (Input.GetKeyDown(KeyCode.R)) { m_vehicle.ResetScene(); }
        if (Input.GetButtonDown("Actuate Slat")) { m_vehicle.ToggleSlatState(); }
        if (Input.GetButtonDown("Spoiler")) { m_vehicle.ToggleSpoilerState(); }
        if (Input.GetButtonDown("Extend Flap")) { m_vehicle.LowerFlaps(); }
        if (Input.GetButtonDown("Retract Flap")) { m_vehicle.RaiseFlaps(); }

        // ----------------------------------------- Keys
        if (Input.GetButton("Brake Lever")) { if (!m_vehicle.brakeLeverHeld) { m_vehicle.brakeLeverHeld = true; } } else { if (m_vehicle.brakeLeverHeld) { m_vehicle.brakeLeverHeld = false; } }
        if (Input.GetButton("Fire")) { if (!m_vehicle.m_triggerHeld) { m_vehicle.m_triggerHeld = true; } } else { if (m_vehicle.m_triggerHeld) { m_vehicle.m_triggerHeld = false; } }

        // ----------------------------------------- Radar
        if (Input.GetButtonDown("Target Up")) { m_vehicle.CycleTargetUpwards(); }
        if (Input.GetButtonDown("Target Down")) { m_vehicle.CycleTargetDownwards(); }
        if (Input.GetButtonDown("Target Lock")) { m_vehicle.LockTarget(); }
        if (Input.GetKeyDown(KeyCode.Backspace)) { m_vehicle.ReleaseTarget(); }
        if (Input.GetKeyDown(KeyCode.Q)) { m_vehicle.SwitchWeapon(); }
        if (Input.GetKeyDown(KeyCode.F)) { m_vehicle.ExitAircraft(); }
    }
}
